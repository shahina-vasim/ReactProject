import React from 'react';
export default function Pagenotfound(){
    return(
        <div class="content-404">
        <img src="images/404/404.png" class="img-responsive" alt="" />
        
    </div>
 )
}