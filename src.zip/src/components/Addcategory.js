import React from 'react'

export default function Addcategory() {
  return (
    <div>Addcategory</div>
  )
}
