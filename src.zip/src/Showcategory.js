import React from 'react'

export default function Showcategory() {
  return (
    <div>Showcategory</div>
  )
}
