import React from "react";
const MainContext=React.createContext();
const UserContext=React.createContext();
export {MainContext,UserContext};